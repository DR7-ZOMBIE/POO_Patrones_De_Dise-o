# Programación Orientada a Objetos 02-2023
*Materia de la carrera CTD - DH*


**Requerimientos:**
- IDE - Intellij
- Java 8
- JDK - Oracle OpenJDK 19
- GIT

**Instrucciones:**
- Debe situarse dentro de la raíz de tu partición y ejecutar la siguiente instrucción: git clone https://github.com/serinformatico/POO-02-2023.git
- Abrí tu IDE y localiza la carpeta "POO-02-2023" que se te ha creado al terminar la clonación
- Para mantener tu repositorio local actualizado, ejecuta antes de cada clase la siguiente instrucción: git pull


*Lic. Sergio Regalado Alessi*
