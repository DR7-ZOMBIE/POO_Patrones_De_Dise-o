package clase_08.extra.herencia.codigo;

public class Clase {
    private String nombre;

    public Clase(String nombre) {
        this.nombre = nombre;
    }
}