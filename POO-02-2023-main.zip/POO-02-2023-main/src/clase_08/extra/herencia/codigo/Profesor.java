package clase_08.extra.herencia.codigo;

public class Profesor {

    // Atributos privados
    protected String materia;

    // Constructor


    // Método público
    public void proponerTema(String tema) {
        // Lógica
    }

    // Getter
    public String getMateria() {
        return this.materia;
    }

    // Setter
    public void setMateria(String temario) {
        this.materia = temario;
    }
}
