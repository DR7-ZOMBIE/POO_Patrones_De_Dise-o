package clase_08.extra.herencia.codigo;

import clase_09.actividad_en_vivo.calefaccion.codigo.Estufa;

public class Experto {

    // Atributos privados
    private String temario;

    // Constructor


    // Método público
    public void dictarClase(Estufa estufa) {
        // Lógica
    }

    // Getter
    public String getTemario() {
        return this.temario;
    }

    // Setter
    public void setTemario(String temario) {
        this.temario = temario;
    }
}
