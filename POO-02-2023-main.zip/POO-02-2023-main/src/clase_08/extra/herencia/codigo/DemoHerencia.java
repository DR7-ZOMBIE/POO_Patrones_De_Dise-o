package clase_08.extra.herencia.codigo;

public class DemoHerencia {
    public static void main(String[] args) {


    }
}
