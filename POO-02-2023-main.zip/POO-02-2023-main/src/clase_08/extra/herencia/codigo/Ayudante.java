package clase_08.extra.herencia.codigo;

public class Ayudante {

    // Constructor


    // Método público
    public void tomarAsistencia() {
        // Lógica
    }
}
