package clase_08.actividad_en_vivo.clinica.codigo;

public class MedicoGeneral extends Medico {

    // Constructor
    public MedicoGeneral(int matricula, String nombre, double honorarioBasico) {
        super(matricula, nombre, honorarioBasico);
    }
}