package clase_08.actividad_en_vivo.clinica.codigo;

public class MedicoAyudante extends Medico {

    // Constructor
    public MedicoAyudante(int matricula, String nombre, double honorarioBasico) {
        super(matricula, nombre, honorarioBasico);
    }
}
