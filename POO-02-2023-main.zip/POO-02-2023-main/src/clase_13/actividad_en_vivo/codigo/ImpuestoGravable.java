package clase_13.actividad_en_vivo.codigo;

public interface ImpuestoGravable {
    public double gravar(double porcentajeDeImpuesto);
}
