package clase_13.extra.codigo;

public interface Registrable {

    // Métodos
    public void anularRegistroDeBono();
    public void registrarBono();
}
