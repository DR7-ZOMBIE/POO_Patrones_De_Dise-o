package clase_20_es_22.actividad_de_mesa.figuras;

public abstract class Figura {

   public Figura() {
   }

   public abstract double calcularSuperficie();


}
