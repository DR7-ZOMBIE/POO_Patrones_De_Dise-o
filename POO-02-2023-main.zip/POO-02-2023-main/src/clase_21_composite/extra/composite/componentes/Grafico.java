package clase_21_composite.extra.composite.componentes;

public interface Grafico {
    public void graficar();
    public void colorear(String color);
}
