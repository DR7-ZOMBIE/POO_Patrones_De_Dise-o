package clase_12.actividad_en_vivo.codigo;

public class Accesorio {
    private String tipo;
    private String color;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
