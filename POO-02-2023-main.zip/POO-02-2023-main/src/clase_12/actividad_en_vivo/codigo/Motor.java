package clase_12.actividad_en_vivo.codigo;

public class Motor {
    private int potenciaEnCv;
    private int cilindradaEnCC;

    public int getPotenciaEnCv() {
        return potenciaEnCv;
    }

    public void setPotenciaEnCv(int potenciaEnCv) {
        this.potenciaEnCv = potenciaEnCv;
    }

    public int getCilindradaEnCC() {
        return cilindradaEnCC;
    }

    public void setCilindradaEnCC(int cilindradaEnCC) {
        this.cilindradaEnCC = cilindradaEnCC;
    }
}
