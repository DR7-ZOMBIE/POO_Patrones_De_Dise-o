package clase_07.extra.codigo.agregacion;

public class Airbag {

    // Atributos privados
    private String denominacion;

    // Constructor
    public Airbag(String denominacion) {
        this.denominacion = denominacion;
    }

    // Getters
    public String getDenominacion() {
        return this.denominacion;
    }

    // Setters
    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }
}
