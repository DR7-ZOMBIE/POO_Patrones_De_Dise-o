package clase_01.playground;

public class SolucionEjercicioAsincrono1 {
    public static void main(String[] args) {

        /* Ejercicio 1:
            Es hora de que crees tus primeras variables en java
            La idea es que crees tres variables: una que se va a llamar numeroEntero y va a ser de tipo int,
            una que se va a llamar numeroConComa de tipo double y por último una llamada nombre de tipo String
            Luego de declararlas asignarles un valor acorde a su tipo.
        */

        int numeroEntero = 10;
        double numeroConComa = 15.5;
        String nombre = "Lorena";
    }
}
