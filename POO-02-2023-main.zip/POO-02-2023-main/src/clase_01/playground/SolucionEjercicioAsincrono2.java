package clase_01.playground;

public class SolucionEjercicioAsincrono2 {
    public static void main(String[] args) {

        /* Ejercicio 2:
            Ahora ya te damos dos variables creadas, numeroEntero y numeroConComa;
            El objetivo del ejercicio es que le asignes un valor acorde a su tipo a cada variable, el valor
            puede ser cualquiera mientras que respetes el tipo de dato.
            Luego vas a declarar la variable suma de tipo double, sumar ambos valores y asignárselos a suma.
        */

        int numeroEntero = 10;
        double numeroConComa = 4.2;

        double suma = numeroConComa + numeroEntero;
    }
}
