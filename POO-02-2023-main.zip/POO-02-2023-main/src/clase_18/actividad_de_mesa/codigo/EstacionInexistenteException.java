package clase_18.actividad_de_mesa.codigo;

public class EstacionInexistenteException extends Exception {
    public EstacionInexistenteException(String mensaje) {
        super(mensaje);
    }
}
