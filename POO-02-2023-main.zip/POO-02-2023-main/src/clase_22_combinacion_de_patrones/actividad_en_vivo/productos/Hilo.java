package clase_22_combinacion_de_patrones.actividad_en_vivo.productos;

public class Hilo extends Producto {

}
