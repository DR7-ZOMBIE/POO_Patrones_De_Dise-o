package clase_22_combinacion_de_patrones.extra.combinacion_de_patrones.componentes;

public interface Grafico {
    public void graficar();
    public void colorear(String color);
}
