package clase_22_combinacion_de_patrones.sabado.productos;

public class Hilo extends Producto {

}
