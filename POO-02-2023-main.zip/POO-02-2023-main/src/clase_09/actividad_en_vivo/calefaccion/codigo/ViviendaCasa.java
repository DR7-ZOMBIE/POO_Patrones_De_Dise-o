package clase_09.actividad_en_vivo.calefaccion.codigo;

public class ViviendaCasa extends Vivienda {

    // Constructor
    public ViviendaCasa(int tamanioEnM2, int cantidadDePersonas) {
        super(tamanioEnM2, cantidadDePersonas);
    }

    // Método público
    public void calcularCalorias() {
        // Lógica
    }
}
