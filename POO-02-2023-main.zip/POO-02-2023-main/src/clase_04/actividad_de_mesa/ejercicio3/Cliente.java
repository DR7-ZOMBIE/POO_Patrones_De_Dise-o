package clase_04.actividad_de_mesa.ejercicio3;

public class Cliente {

    private String nombre;
    private String apellido;
    private double saldo;
    private int cantidadDeConsultasPorPagar;

    public Cliente(String nombre, String apellido) {
        this.nombre   = nombre;
        this.apellido = apellido;
    }

    public void realizarConsulta(double importe) {
        // lógica
    };

    public void pagarConsulta(double importe) {
        // lógica
    };
}
