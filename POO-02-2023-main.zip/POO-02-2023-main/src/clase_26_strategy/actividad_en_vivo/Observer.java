package clase_25_observer.actividad_en_vivo;

public interface Observer {

    public void actualizar();
}
