package clase_25_observer.extra.observer;

public interface Observer {

    public void actualizar();
}
