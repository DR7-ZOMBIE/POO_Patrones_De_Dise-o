package clase_20_state.actividad_en_vivo;

public interface TamagotchiState {

    public void comer();

    public void beber();

    public void mimar();
}
