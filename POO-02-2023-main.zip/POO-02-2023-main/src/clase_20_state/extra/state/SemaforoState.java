package clase_20_state.extra.state;

public interface SemaforoState {

    public void alcanzarLuzVerde();
    public void alcanzarLuzRoja();
}
