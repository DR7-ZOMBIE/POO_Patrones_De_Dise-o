package clase_05.ppt.codigo;

public class Coche {

    // Atributos públicos
    public String marca;
    public String modelo;
    public String color;
    public int anio;
    public double precio;


    // Métodos públicos
    public void encender() {
        // Lógica
    }

    public void avanzar() {
        // Lógica
    }

    public void frenar() {
        // Lógica
    }
}


